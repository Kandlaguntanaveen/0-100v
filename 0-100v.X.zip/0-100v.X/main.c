#include "main.h"
#include "adc.h"
#include "clcd.h"
#include <string.h>
#include <xc.h>



static void init_config(void)
{
    init_adc();
    init_clcd();
}

void main(void)
{
    unsigned short adc_reg_val;

    init_config();

    while (1)
    {
        adc_reg_val = read_adc(CHANNEL4);
        float val=(adc_reg_val/4095.0)*3.3;
        float input_val=val*((100.0 +3.3)/3.3);
        char str[10];
        int i=0;
        while(input_val)
        {
            str[i++]=input_val%10;
            input_val=input_val/10;
        }
        str[i]='0/';
        for(int j=0;j<strlen(str)/2;j++)
        {
           char ch=str[j];
           str[j]=str[strlen(str)-1-j];
           str[strlen(str)-1-j]=ch;
            
        }
        clcd_print("Voltage", LINE1(1));
        clcd_print(str, LINE2(1));
        
    }
}













